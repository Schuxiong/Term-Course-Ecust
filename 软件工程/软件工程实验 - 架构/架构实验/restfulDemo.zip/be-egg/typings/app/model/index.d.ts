// This file is created by egg-ts-helper@1.33.0
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportTodo = require('../../../app/model/Todo');

declare module 'egg' {
  interface IModel {
    Todo: ReturnType<typeof ExportTodo>;
  }
}
