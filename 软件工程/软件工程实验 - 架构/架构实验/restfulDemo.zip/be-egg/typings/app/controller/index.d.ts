// This file is created by egg-ts-helper@1.33.0
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportDemo = require('../../../app/controller/demo');

declare module 'egg' {
  interface IController {
    demo: ExportDemo;
  }
}
